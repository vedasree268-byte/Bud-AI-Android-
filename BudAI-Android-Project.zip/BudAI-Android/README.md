# Bud AI Android wrapper

This project packages the existing Bud AI hosted web app in a standalone Android APK using a native Android WebView shell.

## What this creates
- Android app named **Bud AI**
- Opens the current Bud AI service: https://bud-ai-79knwn.v2.appdeploy.ai/
- JavaScript and DOM storage enabled for the React app
- Android back button navigates web history before exiting
- Network-required AI tutoring and AI-generated visuals
- A GitHub Actions workflow that builds a debug APK and publishes it as a downloadable workflow artifact

## Important limitations
This wrapper does not make the hosted AI backend work offline. AI answers and generated diagrams still require internet. Offline lesson content only works to the extent the existing Bud AI website supports it.
This project has not been compiled in this environment because an Android SDK/Gradle installation is not available here. The GitHub Actions workflow is provided to build a real APK on a GitHub-hosted Android build runner.

## Build the APK using GitHub Actions
1. Create a new GitHub repository (private is fine).
2. Upload the contents of this ZIP to the repository root.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Run **Build Bud AI Android APK** using **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the `bud-ai-debug-apk` artifact.
6. Extract it. The APK is `app-debug.apk`.
7. Transfer that APK to your Android phone and install it. Android may ask you to allow installation from the app you used to open the APK.

## App URL
The app currently loads the deployed Bud AI site. If the site URL changes, edit `APP_URL` in `app/src/main/java/ai/bud/study/MainActivity.java`.

## Security note
Only install APKs you built yourself or trust. The provided GitHub workflow builds a **debug APK**, not a Play Store release-signed APK.
